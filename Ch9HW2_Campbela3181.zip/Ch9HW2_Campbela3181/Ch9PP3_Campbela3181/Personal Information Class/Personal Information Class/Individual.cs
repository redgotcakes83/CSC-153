﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personal_Information_Class
{
    class Individual
    {
        // Private fields for Class.
        private string _name;
        private string _address;
        private int _age;
        private string _phoneNumber;

        // Set & Get for Name Property.
        public String Name
        {
            set { _name = value; }
            get { return _name; }
        }

        // Set & Get for Address Property.
        public String Address
        {
            set { _address = value; }
            get { return _address; }
        }

        // Set & Get for Age Property.
        public int Age
        {
            set { _age = value; }
            get { return _age; }
        }

        // Set & Get for Phone Number Property.
        public string PhoneNumber
        {
            set { _phoneNumber = value; }
            get { return _phoneNumber; }
        }
    }
}
