﻿namespace Personal_Information_Class
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.personalInfoLabel = new System.Windows.Forms.Label();
            this.myInfoLabel = new System.Windows.Forms.Label();
            this.mothersInfoLabel = new System.Windows.Forms.Label();
            this.fathersInfoLabel = new System.Windows.Forms.Label();
            this.sistersInfoLabel = new System.Windows.Forms.Label();
            this.myInfoTextBox = new System.Windows.Forms.TextBox();
            this.mothersInfoTextBox = new System.Windows.Forms.TextBox();
            this.fathersInfoTextBox = new System.Windows.Forms.TextBox();
            this.sistersInfoTextBox = new System.Windows.Forms.TextBox();
            this.displayButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // personalInfoLabel
            // 
            this.personalInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.personalInfoLabel.Location = new System.Drawing.Point(222, 28);
            this.personalInfoLabel.Name = "personalInfoLabel";
            this.personalInfoLabel.Size = new System.Drawing.Size(209, 23);
            this.personalInfoLabel.TabIndex = 0;
            this.personalInfoLabel.Text = "Personal Information";
            // 
            // myInfoLabel
            // 
            this.myInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.myInfoLabel.Location = new System.Drawing.Point(59, 78);
            this.myInfoLabel.Name = "myInfoLabel";
            this.myInfoLabel.Size = new System.Drawing.Size(118, 23);
            this.myInfoLabel.TabIndex = 1;
            this.myInfoLabel.Text = "My Information";
            // 
            // mothersInfoLabel
            // 
            this.mothersInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mothersInfoLabel.Location = new System.Drawing.Point(59, 116);
            this.mothersInfoLabel.Name = "mothersInfoLabel";
            this.mothersInfoLabel.Size = new System.Drawing.Size(100, 23);
            this.mothersInfoLabel.TabIndex = 2;
            this.mothersInfoLabel.Text = "Mother";
            // 
            // fathersInfoLabel
            // 
            this.fathersInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fathersInfoLabel.Location = new System.Drawing.Point(59, 152);
            this.fathersInfoLabel.Name = "fathersInfoLabel";
            this.fathersInfoLabel.Size = new System.Drawing.Size(100, 23);
            this.fathersInfoLabel.TabIndex = 3;
            this.fathersInfoLabel.Text = "Father";
            // 
            // sistersInfoLabel
            // 
            this.sistersInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sistersInfoLabel.Location = new System.Drawing.Point(59, 189);
            this.sistersInfoLabel.Name = "sistersInfoLabel";
            this.sistersInfoLabel.Size = new System.Drawing.Size(100, 23);
            this.sistersInfoLabel.TabIndex = 4;
            this.sistersInfoLabel.Text = "Sister";
            // 
            // myInfoTextBox
            // 
            this.myInfoTextBox.Location = new System.Drawing.Point(174, 78);
            this.myInfoTextBox.Name = "myInfoTextBox";
            this.myInfoTextBox.Size = new System.Drawing.Size(347, 20);
            this.myInfoTextBox.TabIndex = 5;
            // 
            // mothersInfoTextBox
            // 
            this.mothersInfoTextBox.Location = new System.Drawing.Point(174, 116);
            this.mothersInfoTextBox.Name = "mothersInfoTextBox";
            this.mothersInfoTextBox.Size = new System.Drawing.Size(347, 20);
            this.mothersInfoTextBox.TabIndex = 6;
            // 
            // fathersInfoTextBox
            // 
            this.fathersInfoTextBox.Location = new System.Drawing.Point(174, 152);
            this.fathersInfoTextBox.Name = "fathersInfoTextBox";
            this.fathersInfoTextBox.Size = new System.Drawing.Size(347, 20);
            this.fathersInfoTextBox.TabIndex = 7;
            // 
            // sistersInfoTextBox
            // 
            this.sistersInfoTextBox.Location = new System.Drawing.Point(174, 189);
            this.sistersInfoTextBox.Name = "sistersInfoTextBox";
            this.sistersInfoTextBox.Size = new System.Drawing.Size(347, 20);
            this.sistersInfoTextBox.TabIndex = 8;
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(226, 231);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(101, 40);
            this.displayButton.TabIndex = 9;
            this.displayButton.Text = "Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(358, 231);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(101, 40);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(555, 296);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.sistersInfoTextBox);
            this.Controls.Add(this.fathersInfoTextBox);
            this.Controls.Add(this.mothersInfoTextBox);
            this.Controls.Add(this.myInfoTextBox);
            this.Controls.Add(this.sistersInfoLabel);
            this.Controls.Add(this.fathersInfoLabel);
            this.Controls.Add(this.mothersInfoLabel);
            this.Controls.Add(this.myInfoLabel);
            this.Controls.Add(this.personalInfoLabel);
            this.Name = "MainForm";
            this.Text = "Personal Information";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label personalInfoLabel;
        private System.Windows.Forms.Label myInfoLabel;
        private System.Windows.Forms.Label mothersInfoLabel;
        private System.Windows.Forms.Label fathersInfoLabel;
        private System.Windows.Forms.Label sistersInfoLabel;
        private System.Windows.Forms.TextBox myInfoTextBox;
        private System.Windows.Forms.TextBox mothersInfoTextBox;
        private System.Windows.Forms.TextBox fathersInfoTextBox;
        private System.Windows.Forms.TextBox sistersInfoTextBox;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.Button exitButton;
    }
}

