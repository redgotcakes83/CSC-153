﻿/**
* 5-14-2018
* CSC 153
* Alicia Brown
* This program uses a class and array to display personal information loaded into
* the main form.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Personal_Information_Class
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        // Array reference for Individual class
        private Individual[] familyMem = new Individual[4];

        private void MainForm_Load(object sender, EventArgs e)
        {
            // Form Load event to initialize an array reference for all members of the family.
            // Properties for object at Index 0.
            familyMem[0] = new Individual();
            familyMem[0].Name = "Alicia Brown";
            familyMem[0].Address = "Fayetteville, NC";
            familyMem[0].Age = 31;
            familyMem[0].PhoneNumber = "123-456-789";

            // Properties for object at Index 1.
            familyMem[1] = new Individual();
            familyMem[1].Name = "Angela Miller";
            familyMem[1].Address = "Nathalie, Va";
            familyMem[1].Age = 55;
            familyMem[1].PhoneNumber = "123-456-789";

            // Properties for object at Index 2.
            familyMem[2] = new Individual();
            familyMem[2].Name = "David Brown";
            familyMem[2].Address = "Salisbury, MD";
            familyMem[2].Age = 52;
            familyMem[2].PhoneNumber = "123-654-555";

            // Properties for object at Index 3.
            familyMem[3] = new Individual();
            familyMem[3].Name = "Tiara Crews";
            familyMem[3].Address = "South Boston, VA";
            familyMem[3].Age = 28;
            familyMem[3].PhoneNumber = "123-654-555";
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            // Display information to corresponding text boxes.
            // My Info
            myInfoTextBox.Text = familyMem[0].Name + ", " + familyMem[0].Address + ", " + familyMem[0].Age + ", " + familyMem[0].PhoneNumber;
            // Mother's Info
            mothersInfoTextBox.Text = familyMem[1].Name + ", " + familyMem[1].Address + ", " + familyMem[1].Age + ", " + familyMem[1].PhoneNumber;
            // Father's Info
            fathersInfoTextBox.Text = familyMem[2].Name + ", " + familyMem[2].Address + ", " + familyMem[2].Age + ", " + familyMem[2].PhoneNumber;
            // Sister's Info
            sistersInfoTextBox.Text = familyMem[3].Name + ", " + familyMem[3].Address + ", " + familyMem[3].Age + ", " + familyMem[3].PhoneNumber;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close this form.
            this.Close();
        }
    }
}
