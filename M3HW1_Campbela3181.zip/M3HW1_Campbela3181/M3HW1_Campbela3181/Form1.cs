﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 2-27-2018
* CSC 153
* Alicia Campbell-Brown
* M3HW1
*/

namespace M3HW1_Campbela3181
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {

            int number = 0;
            int.TryParse(NumeralTextBox.Text, out number);

            switch (number)
            {
                case 1:
                    MessageBox.Show("I");
                    break;
                case 2:
                    MessageBox.Show("II");
                    break;
                case 3:
                    MessageBox.Show("III");
                    break;
                case 4:
                    MessageBox.Show("IV");
                    break;
                case 5:
                    MessageBox.Show("V");
                    break;
                case 6:
                    MessageBox.Show("VI");
                    break;
                case 7:
                    MessageBox.Show("VII");
                    break;
                case 8:
                    MessageBox.Show("VIII");
                    break;
                case 9:
                    MessageBox.Show("IX");
                    break;
                case 10:
                    MessageBox.Show("X");
                    break;
                default:
                    MessageBox.Show("Error: Invalid Number");
                    break;
            }
        }      
    }
}
