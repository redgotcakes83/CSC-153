﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Campbela3181_CardIdentifier
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void jackofdiamondsBox_Click(object sender, EventArgs e)
        {
            suiteLabel.Text = "Jack of Diamonds";
        }

        private void eightofheartsBox_Click(object sender, EventArgs e)
        {
            suiteLabel.Text = "Eight of Hearts";
        }

        private void aceofclubsBox_Click(object sender, EventArgs e)
        {
            suiteLabel.Text = "Ace of Clubs";
        }

        private void kingofclubsBox_Click(object sender, EventArgs e)
        {
            suiteLabel.Text = "King of Clubs";
        }

        private void aceofdiamondsBox_Click(object sender, EventArgs e)
        {
            suiteLabel.Text = "Ace of Diamonds";
        }
    }
    }

