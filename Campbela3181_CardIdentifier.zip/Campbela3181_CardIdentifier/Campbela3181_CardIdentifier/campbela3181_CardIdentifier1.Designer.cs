﻿namespace Campbela3181_CardIdentifier
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.instructionLabel = new System.Windows.Forms.Label();
            this.jackofdiamondsBox = new System.Windows.Forms.PictureBox();
            this.eightofheartsBox = new System.Windows.Forms.PictureBox();
            this.aceofclubsBox = new System.Windows.Forms.PictureBox();
            this.kingofclubsBox = new System.Windows.Forms.PictureBox();
            this.aceofdiamondsBox = new System.Windows.Forms.PictureBox();
            this.suiteLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.jackofdiamondsBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eightofheartsBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceofclubsBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingofclubsBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceofdiamondsBox)).BeginInit();
            this.SuspendLayout();
            // 
            // instructionLabel
            // 
            this.instructionLabel.AutoSize = true;
            this.instructionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructionLabel.Location = new System.Drawing.Point(68, 18);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(485, 29);
            this.instructionLabel.TabIndex = 0;
            this.instructionLabel.Text = "Click a card to see the name of the suite.";
            this.instructionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jackofdiamondsBox
            // 
            this.jackofdiamondsBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.jackofdiamondsBox.Image = ((System.Drawing.Image)(resources.GetObject("jackofdiamondsBox.Image")));
            this.jackofdiamondsBox.Location = new System.Drawing.Point(1, 76);
            this.jackofdiamondsBox.Name = "jackofdiamondsBox";
            this.jackofdiamondsBox.Size = new System.Drawing.Size(109, 162);
            this.jackofdiamondsBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.jackofdiamondsBox.TabIndex = 1;
            this.jackofdiamondsBox.TabStop = false;
            this.jackofdiamondsBox.Click += new System.EventHandler(this.jackofdiamondsBox_Click);
            // 
            // eightofheartsBox
            // 
            this.eightofheartsBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.eightofheartsBox.Image = ((System.Drawing.Image)(resources.GetObject("eightofheartsBox.Image")));
            this.eightofheartsBox.Location = new System.Drawing.Point(116, 91);
            this.eightofheartsBox.Name = "eightofheartsBox";
            this.eightofheartsBox.Size = new System.Drawing.Size(108, 147);
            this.eightofheartsBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.eightofheartsBox.TabIndex = 2;
            this.eightofheartsBox.TabStop = false;
            this.eightofheartsBox.Click += new System.EventHandler(this.eightofheartsBox_Click);
            // 
            // aceofclubsBox
            // 
            this.aceofclubsBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aceofclubsBox.Image = ((System.Drawing.Image)(resources.GetObject("aceofclubsBox.Image")));
            this.aceofclubsBox.Location = new System.Drawing.Point(230, 76);
            this.aceofclubsBox.Name = "aceofclubsBox";
            this.aceofclubsBox.Size = new System.Drawing.Size(109, 162);
            this.aceofclubsBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.aceofclubsBox.TabIndex = 3;
            this.aceofclubsBox.TabStop = false;
            this.aceofclubsBox.Click += new System.EventHandler(this.aceofclubsBox_Click);
            // 
            // kingofclubsBox
            // 
            this.kingofclubsBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.kingofclubsBox.Image = ((System.Drawing.Image)(resources.GetObject("kingofclubsBox.Image")));
            this.kingofclubsBox.Location = new System.Drawing.Point(360, 76);
            this.kingofclubsBox.Name = "kingofclubsBox";
            this.kingofclubsBox.Size = new System.Drawing.Size(120, 162);
            this.kingofclubsBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.kingofclubsBox.TabIndex = 4;
            this.kingofclubsBox.TabStop = false;
            this.kingofclubsBox.Click += new System.EventHandler(this.kingofclubsBox_Click);
            // 
            // aceofdiamondsBox
            // 
            this.aceofdiamondsBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aceofdiamondsBox.Image = ((System.Drawing.Image)(resources.GetObject("aceofdiamondsBox.Image")));
            this.aceofdiamondsBox.Location = new System.Drawing.Point(502, 76);
            this.aceofdiamondsBox.Name = "aceofdiamondsBox";
            this.aceofdiamondsBox.Size = new System.Drawing.Size(105, 156);
            this.aceofdiamondsBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.aceofdiamondsBox.TabIndex = 5;
            this.aceofdiamondsBox.TabStop = false;
            this.aceofdiamondsBox.Click += new System.EventHandler(this.aceofdiamondsBox_Click);
            // 
            // suiteLabel
            // 
            this.suiteLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.suiteLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.suiteLabel.Location = new System.Drawing.Point(17, 291);
            this.suiteLabel.Name = "suiteLabel";
            this.suiteLabel.Size = new System.Drawing.Size(578, 40);
            this.suiteLabel.TabIndex = 6;
            this.suiteLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(629, 357);
            this.Controls.Add(this.suiteLabel);
            this.Controls.Add(this.aceofdiamondsBox);
            this.Controls.Add(this.kingofclubsBox);
            this.Controls.Add(this.aceofclubsBox);
            this.Controls.Add(this.eightofheartsBox);
            this.Controls.Add(this.jackofdiamondsBox);
            this.Controls.Add(this.instructionLabel);
            this.Name = "Form1";
            this.Text = "Card Identifier";
            ((System.ComponentModel.ISupportInitialize)(this.jackofdiamondsBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eightofheartsBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceofclubsBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingofclubsBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceofdiamondsBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.PictureBox jackofdiamondsBox;
        private System.Windows.Forms.PictureBox eightofheartsBox;
        private System.Windows.Forms.PictureBox aceofclubsBox;
        private System.Windows.Forms.PictureBox kingofclubsBox;
        private System.Windows.Forms.PictureBox aceofdiamondsBox;
        private System.Windows.Forms.Label suiteLabel;
    }
}

