﻿/**
* 4-20-2018
* CSC 153
* Alicia Brown
* Distance
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Falling_Distance
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
           
            double distanceValue;
            double time;

           
            time = double.Parse(secondsTextBox.Text);

            
            distanceValue = FallingDistance(time);
           
            MessageBox.Show("The distance the object has fallen is "
                + distanceValue + " meters.");
        }
            
            /** Formula to determine the distance the object falls in a specific
             time period.
             d=1/2*g*t^2 
             d = distance in meters.
             g = gravity and the value is 9.8.
             t = time in seconds the object has been falling.
             */

           
         private double FallingDistance(double time)
        {
           
            return 0.5 * 9.8 * (time*=time);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            
            secondsTextBox.Text = "";
        }
    }
}