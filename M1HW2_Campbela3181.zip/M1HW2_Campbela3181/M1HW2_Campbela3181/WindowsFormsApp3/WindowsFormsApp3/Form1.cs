﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
*5-14-2018
* CSC 153
* Alicia Brown
* This program display a messages after clicking ont the cards
*/

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sixofHeart_Click(object sender, EventArgs e)
        {
            cardLable.Text = "***Six of Hearts***";
        }

        private void nineofSpade_Click(object sender, EventArgs e)
        {
            cardLable.Text = "***Nine of Spades*** ";
        }

        private void jackofDiamond_Click(object sender, EventArgs e)
        {
            cardLable.Text = "***Jack of Clubs***";

        }

        private void kingofDiamond_Click(object sender, EventArgs e)
        {
            cardLable.Text = "***King of Clubs***";
        }

        private void JokerCard_Click(object sender, EventArgs e)
        {
            cardLable.Text = "***Joker***";
      
        }

    }
}
