﻿namespace Payroll_with_Overtime
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hoursworkedLabel = new System.Windows.Forms.Label();
            this.hoursworkedtextBox = new System.Windows.Forms.TextBox();
            this.hourlypayrateLabel = new System.Windows.Forms.Label();
            this.hourlyPayRateTextBox = new System.Windows.Forms.TextBox();
            this.grosspayPromptLabel = new System.Windows.Forms.Label();
            this.grossPayLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearbutton = new System.Windows.Forms.Button();
            this.Exitbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // hoursworkedLabel
            // 
            this.hoursworkedLabel.AutoSize = true;
            this.hoursworkedLabel.Location = new System.Drawing.Point(13, 43);
            this.hoursworkedLabel.Name = "hoursworkedLabel";
            this.hoursworkedLabel.Size = new System.Drawing.Size(79, 13);
            this.hoursworkedLabel.TabIndex = 0;
            this.hoursworkedLabel.Text = "Hours Worked:";
            // 
            // hoursworkedtextBox
            // 
            this.hoursworkedtextBox.Location = new System.Drawing.Point(124, 41);
            this.hoursworkedtextBox.Name = "hoursworkedtextBox";
            this.hoursworkedtextBox.Size = new System.Drawing.Size(118, 20);
            this.hoursworkedtextBox.TabIndex = 1;
            // 
            // hourlypayrateLabel
            // 
            this.hourlypayrateLabel.AutoSize = true;
            this.hourlypayrateLabel.Location = new System.Drawing.Point(13, 80);
            this.hourlypayrateLabel.Name = "hourlypayrateLabel";
            this.hourlypayrateLabel.Size = new System.Drawing.Size(81, 13);
            this.hourlypayrateLabel.TabIndex = 2;
            this.hourlypayrateLabel.Text = "Hourly pay rate:";
            // 
            // hourlyPayRateTextBox
            // 
            this.hourlyPayRateTextBox.Location = new System.Drawing.Point(126, 73);
            this.hourlyPayRateTextBox.Name = "hourlyPayRateTextBox";
            this.hourlyPayRateTextBox.Size = new System.Drawing.Size(115, 20);
            this.hourlyPayRateTextBox.TabIndex = 3;
            // 
            // grosspayPromptLabel
            // 
            this.grosspayPromptLabel.AutoSize = true;
            this.grosspayPromptLabel.Location = new System.Drawing.Point(65, 125);
            this.grosspayPromptLabel.Name = "grosspayPromptLabel";
            this.grosspayPromptLabel.Size = new System.Drawing.Size(57, 13);
            this.grosspayPromptLabel.TabIndex = 4;
            this.grosspayPromptLabel.Text = "Gross pay:";
            // 
            // grossPayLabel
            // 
            this.grossPayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.grossPayLabel.Location = new System.Drawing.Point(141, 125);
            this.grossPayLabel.Name = "grossPayLabel";
            this.grossPayLabel.Size = new System.Drawing.Size(99, 22);
            this.grossPayLabel.TabIndex = 5;
            this.grossPayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(14, 200);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(77, 34);
            this.calculateButton.TabIndex = 6;
            this.calculateButton.Text = "Calculate Gross Pay";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearbutton
            // 
            this.clearbutton.Location = new System.Drawing.Point(111, 199);
            this.clearbutton.Name = "clearbutton";
            this.clearbutton.Size = new System.Drawing.Size(76, 34);
            this.clearbutton.TabIndex = 7;
            this.clearbutton.Text = "Clear";
            this.clearbutton.UseVisualStyleBackColor = true;
            this.clearbutton.Click += new System.EventHandler(this.clearbutton_Click);
            // 
            // Exitbutton
            // 
            this.Exitbutton.Location = new System.Drawing.Point(206, 199);
            this.Exitbutton.Name = "Exitbutton";
            this.Exitbutton.Size = new System.Drawing.Size(66, 32);
            this.Exitbutton.TabIndex = 8;
            this.Exitbutton.Text = "Exit";
            this.Exitbutton.UseVisualStyleBackColor = true;
            this.Exitbutton.Click += new System.EventHandler(this.Exitbutton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.Exitbutton);
            this.Controls.Add(this.clearbutton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.grossPayLabel);
            this.Controls.Add(this.grosspayPromptLabel);
            this.Controls.Add(this.hourlyPayRateTextBox);
            this.Controls.Add(this.hourlypayrateLabel);
            this.Controls.Add(this.hoursworkedtextBox);
            this.Controls.Add(this.hoursworkedLabel);
            this.Name = "Form1";
            this.Text = "Payroll with Overtime";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label hoursworkedLabel;
        private System.Windows.Forms.TextBox hoursworkedtextBox;
        private System.Windows.Forms.Label hourlypayrateLabel;
        private System.Windows.Forms.TextBox hourlyPayRateTextBox;
        private System.Windows.Forms.Label grosspayPromptLabel;
        private System.Windows.Forms.Label grossPayLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearbutton;
        private System.Windows.Forms.Button Exitbutton;
    }
}

